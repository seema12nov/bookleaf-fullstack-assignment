const db = require("../config/db");

// ===============================
// CREATE BOOK
// ===============================

const createBook = async (req, res) => {
    try {
        const {
            title,
            description,
            category,
            cover_image
        } = req.body;

        if (!title) {
            return res.status(400).json({
                success: false,
                message: "Book title is required"
            });
        }

        const userId = req.user.id;

        const [result] = await db.query(
            `INSERT INTO books
            (user_id, title, description, category, cover_image, status)
            VALUES (?, ?, ?, ?, ?, ?)`,
            [
                userId,
                title,
                description || null,
                category || null,
                cover_image || null,
                "Pending"
            ]
        );

        return res.status(201).json({
            success: true,
            message: "Book created successfully",
            bookId: result.insertId
        });

    } catch (error) {
        console.error("Create Book Error:", error);

        return res.status(500).json({
            success: false,
            message: "Server error"
        });
    }
};


// ===============================
// GET ALL MY BOOKS
// ===============================

const getBooks = async (req, res) => {
    try {
        const userId = req.user.id;

        const [books] = await db.query(
            `SELECT *
             FROM books
             WHERE user_id = ?
             ORDER BY id DESC`,
            [userId]
        );

        return res.status(200).json({
            success: true,
            count: books.length,
            books
        });

    } catch (error) {
        console.error("Get Books Error:", error);

        return res.status(500).json({
            success: false,
            message: "Server error"
        });
    }
};


// ===============================
// GET SINGLE BOOK
// ===============================

const getBookById = async (req, res) => {
    try {
        const userId = req.user.id;
        const bookId = req.params.id;

        const [books] = await db.query(
            `SELECT *
             FROM books
             WHERE id = ? AND user_id = ?`,
            [bookId, userId]
        );

        if (books.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Book not found"
            });
        }

        return res.status(200).json({
            success: true,
            book: books[0]
        });

    } catch (error) {
        console.error("Get Book Error:", error);

        return res.status(500).json({
            success: false,
            message: "Server error"
        });
    }
};


// ===============================
// UPDATE BOOK
// ===============================

const updateBook = async (req, res) => {
    try {
        const userId = req.user.id;
        const bookId = req.params.id;

        const {
            title,
            description,
            category,
            cover_image
        } = req.body;

        if (!title) {
            return res.status(400).json({
                success: false,
                message: "Book title is required"
            });
        }

        const [result] = await db.query(
            `UPDATE books
             SET title = ?,
                 description = ?,
                 category = ?,
                 cover_image = ?
             WHERE id = ? AND user_id = ?`,
            [
                title,
                description || null,
                category || null,
                cover_image || null,
                bookId,
                userId
            ]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Book not found"
            });
        }

        return res.status(200).json({
            success: true,
            message: "Book updated successfully"
        });

    } catch (error) {
        console.error("Update Book Error:", error);

        return res.status(500).json({
            success: false,
            message: "Server error"
        });
    }
};


// ===============================
// DELETE BOOK
// ===============================

const deleteBook = async (req, res) => {
    try {
        const userId = req.user.id;
        const bookId = req.params.id;

        const [result] = await db.query(
            `DELETE FROM books
             WHERE id = ? AND user_id = ?`,
            [bookId, userId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Book not found"
            });
        }

        return res.status(200).json({
            success: true,
            message: "Book deleted successfully"
        });

    } catch (error) {
        console.error("Delete Book Error:", error);

        return res.status(500).json({
            success: false,
            message: "Server error"
        });
    }
};


// ===============================
// EXPORT
// ===============================

module.exports = {
    createBook,
    getBooks,
    getBookById,
    updateBook,
    deleteBook
};