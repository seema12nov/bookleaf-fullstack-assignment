const db = require("../config/db");

// ===============================
// GET ALL BOOKS
// ===============================

const getAllBooks = async (req, res) => {
    try {

        const [books] = await db.query(`
            SELECT
                books.id,
                books.title,
                books.description,
                books.category,
                books.cover_image,
                books.status,
                books.created_at,
                books.updated_at,
                users.id AS author_id,
                users.name AS author_name,
                users.email AS author_email
            FROM books
            INNER JOIN users
                ON books.user_id = users.id
            ORDER BY books.id DESC
        `);

        return res.status(200).json({
            success: true,
            count: books.length,
            books
        });

    } catch (error) {

        console.error("Get All Books Error:", error);

        return res.status(500).json({
            success: false,
            message: "Server error"
        });
    }
};


// ===============================
// UPDATE BOOK STATUS
// ===============================

const updateBookStatus = async (req, res) => {
    try {

        const bookId = req.params.id;
        const { status } = req.body;

        // Allowed statuses
        const allowedStatuses = [
            "Pending",
            "Approved",
            "Rejected",
            "Published"
        ];

        if (!status) {
            return res.status(400).json({
                success: false,
                message: "Status is required"
            });
        }

        if (!allowedStatuses.includes(status)) {
            return res.status(400).json({
                success: false,
                message: "Invalid book status"
            });
        }

        const [result] = await db.query(
            `UPDATE books
             SET status = ?
             WHERE id = ?`,
            [status, bookId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Book not found"
            });
        }

        return res.status(200).json({
            success: true,
            message: "Book status updated successfully"
        });

    } catch (error) {

        console.error("Update Book Status Error:", error);

        return res.status(500).json({
            success: false,
            message: "Server error"
        });
    }
};


// ===============================
// EXPORT
// ===============================

module.exports = {
    getAllBooks,
    updateBookStatus
};