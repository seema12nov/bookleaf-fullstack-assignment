
const {
    generateBookDescription
} = require("../services/openaiService");

// ===============================
// GENERATE BOOK DESCRIPTION
// ===============================

const generateDescription = async (req, res) => {
    try {

        const { title, category } = req.body;

        // Validate title
        if (!title) {
            return res.status(400).json({
                success: false,
                message: "Book title is required"
            });
        }

        // Call OpenAI service
        const description = await generateBookDescription(
            title,
            category
        );

        return res.status(200).json({
            success: true,
            message: "Book description generated successfully",
            description
        });

    } catch (error) {

        console.error("========== GENERATE DESCRIPTION ERROR ==========");
        console.error("Message:", error.message);
        console.error("Status:", error.status);
        console.error("Code:", error.code);
        console.error("Full Error:", error);
        console.error("=================================================");

        return res.status(500).json({
            success: false,
            message: "Failed to generate book description",
            error: error.message
        });
    }
};

module.exports = {
    generateDescription
};

