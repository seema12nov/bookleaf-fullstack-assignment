const express = require("express");

const {
    generateDescription
} = require("../controllers/aiController");

const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// Generate AI book description
router.post(
    "/generate-description",
    authMiddleware,
    generateDescription
);

module.exports = router;