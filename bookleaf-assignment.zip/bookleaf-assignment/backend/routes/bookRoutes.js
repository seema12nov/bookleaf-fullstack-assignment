 
const express = require("express");

const {
    createBook,
    getBooks,
    getBookById,
    updateBook,
    deleteBook
} = require("../controllers/bookController");

const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// ===============================
// CREATE BOOK
// ===============================

router.post("/", authMiddleware, createBook);

// ===============================
// GET ALL BOOKS
// ===============================

router.get("/", authMiddleware, getBooks);

// ===============================
// GET SINGLE BOOK
// ===============================

router.get("/:id", authMiddleware, getBookById);

// ===============================
// UPDATE BOOK
// ===============================

router.put("/:id", authMiddleware, updateBook);

// ===============================
// DELETE BOOK
// ===============================

router.delete("/:id", authMiddleware, deleteBook);

// ===============================
// EXPORT ROUTER
// ===============================

module.exports = router;
