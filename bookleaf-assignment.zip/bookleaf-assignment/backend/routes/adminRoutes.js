const express = require("express");

const {
    getAllBooks,
    updateBookStatus
} = require("../controllers/adminController");

const authMiddleware = require("../middleware/authMiddleware");
const adminMiddleware = require("../middleware/adminMiddleware");

const router = express.Router();

// ===============================
// ADMIN ROUTES
// ===============================

// Get all books
router.get(
    "/books",
    authMiddleware,
    adminMiddleware,
    getAllBooks
);

// Update book status
router.put(
    "/books/:id/status",
    authMiddleware,
    adminMiddleware,
    updateBookStatus
);

module.exports = router;