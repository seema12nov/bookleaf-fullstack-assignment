
// Temporary Mock AI Service
// OpenAI API key ke bina testing ke liye use ho raha hai.

const generateBookDescription = async (title, category) => {
    const bookCategory = category || "General";

    return `Discover "${title}", an engaging ${bookCategory} book created to offer readers valuable insights and an enjoyable reading experience. With a clear and accessible approach, this book explores meaningful ideas and practical perspectives that readers can connect with. Whether you are looking to learn something new, explore fresh concepts, or simply enjoy an engaging read, "${title}" provides content designed to keep you interested from beginning to end. It is suitable for readers who appreciate thoughtful and relevant books in the ${bookCategory} category.`;
};

module.exports = {
    generateBookDescription
};

