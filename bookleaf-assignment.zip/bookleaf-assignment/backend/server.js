const express = require("express");
const cors = require("cors");
require("dotenv").config();

const db = require("./config/db");

// ===============================
// ROUTES
// ===============================

const authRoutes = require("./routes/authRoutes");
const bookRoutes = require("./routes/bookRoutes");
const adminRoutes = require("./routes/adminRoutes");
const aiRoutes = require("./routes/aiRoutes");

// ===============================
// EXPRESS APP
// ===============================

const app = express();

const PORT = process.env.PORT || 5000;

// ===============================
// ROUTE VALIDATION
// ===============================

console.log("Checking route imports...");

console.log("Auth Routes:", typeof authRoutes);
console.log("Book Routes:", typeof bookRoutes);
console.log("Admin Routes:", typeof adminRoutes);
console.log("AI Routes:", typeof aiRoutes);

// ===============================
// CORS CONFIGURATION
// ===============================

const allowedOrigins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173"
];

app.use(
    cors({
        origin: function (origin, callback) {

            // Allow Postman / requests without origin
            if (!origin) {
                return callback(null, true);
            }

            // Allow React/Vite frontend
            if (allowedOrigins.includes(origin)) {
                return callback(null, true);
            }

            return callback(
                new Error("Not allowed by CORS")
            );
        },

        credentials: true
    })
);

// ===============================
// MIDDLEWARE
// ===============================

app.use(express.json());

app.use(
    express.urlencoded({
        extended: true
    })
);

// ===============================
// HEALTH CHECK
// ===============================

app.get("/", (req, res) => {

    res.status(200).json({
        success: true,
        message: "BookLeaf Backend API is running"
    });

});

// ===============================
// AUTH ROUTES
// ===============================

app.use("/api/auth", authRoutes);

// ===============================
// BOOK ROUTES
// ===============================

app.use("/api/books", bookRoutes);

// ===============================
// ADMIN ROUTES
// ===============================

app.use("/api/admin", adminRoutes);

// ===============================
// AI ROUTES
// ===============================

app.use("/api/ai", aiRoutes);

// ===============================
// 404 HANDLER
// ===============================

app.use((req, res) => {

    res.status(404).json({
        success: false,
        message: "API route not found"
    });

});

// ===============================
// ERROR HANDLER
// ===============================

app.use((err, req, res, next) => {

    console.error(
        "Server Error:",
        err.message
    );

    res.status(500).json({
        success: false,
        message: err.message || "Internal Server Error"
    });

});

// ===============================
// DATABASE CONNECTION
// ===============================

async function connectDatabase() {

    try {

        const connection = await db.getConnection();

        console.log(
            "MySQL database connected successfully"
        );

        connection.release();

    } catch (error) {

        console.error(
            "Database connection failed:",
            error.message
        );

    }

}

// ===============================
// START SERVER
// ===============================

async function startServer() {

    await connectDatabase();

    app.listen(PORT, () => {

        console.log(
            `Server running on http://localhost:${PORT}`
        );

    });

}

startServer();