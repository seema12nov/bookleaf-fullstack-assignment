
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function ManageBooks() {
    const navigate = useNavigate();

    const [books, setBooks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [search, setSearch] = useState("");
    const [statusFilter, setStatusFilter] = useState("All");

    const user = JSON.parse(
        localStorage.getItem("user") || "{}"
    );

    const token = localStorage.getItem("token");

    useEffect(() => {
        fetchBooks();
    }, []);

    const fetchBooks = async () => {
        try {
            setLoading(true);
            setError("");

            const response = await axios.get(
                "http://localhost:5000/api/admin/books",
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            if (response.data.success) {
                setBooks(response.data.books || []);
            }
        } catch (err) {
            console.error("Manage Books Error:", err);

            setError(
                err.response?.data?.message ||
                "Unable to load books."
            );
        } finally {
            setLoading(false);
        }
    };

    const handleLogout = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");

        navigate("/login");
    };

    const filteredBooks = books.filter((book) => {

        const searchText = search.toLowerCase();

        const matchesSearch =
            book.title?.toLowerCase().includes(searchText) ||
            book.author_name?.toLowerCase().includes(searchText) ||
            book.author_email?.toLowerCase().includes(searchText) ||
            book.category?.toLowerCase().includes(searchText);

        const matchesStatus =
            statusFilter === "All" ||
            book.status === statusFilter;

        return matchesSearch && matchesStatus;
    });

    const getStatusClass = (status) => {
        return status?.toLowerCase() || "pending";
    };

    return (
        <div className="admin-layout">

            {/* SIDEBAR */}

            <aside className="admin-sidebar">

                <div className="sidebar-brand">

                    <div className="sidebar-logo">
                        <img
                            src="https://static.wixstatic.com/media/6d2cdc_fbad8eb25d304d57be46e9c494a1a355~mv2.jpg/v1/fill/w_360,h_162,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/book%20background%20white.jpg"
                            alt="BookLeaf"
                        />
                    </div>

                </div>

                <nav className="sidebar-nav">

                    <button
                        className="nav-item"
                        onClick={() =>
                            navigate("/dashboard")
                        }
                    >
                        <span>▦</span>
                        Dashboard
                    </button>

                    <button
                        className="nav-item active"
                        onClick={() =>
                            navigate("/books")
                        }
                    >
                        <span>▤</span>
                        Manage Books
                    </button>

                </nav>

                <div className="sidebar-bottom">

                    <div className="admin-mini">

                        <div className="admin-avatar">
                            {user.name
                                ? user.name
                                      .charAt(0)
                                      .toUpperCase()
                                : "A"}
                        </div>

                        <div>
                            <strong>
                                {user.name ||
                                    "Administrator"}
                            </strong>

                            <small>
                                Administrator
                            </small>
                        </div>

                    </div>

                    <button
                        className="logout-button"
                        onClick={handleLogout}
                    >
                        <span>↪</span>
                        Logout
                    </button>

                </div>

            </aside>

            {/* MAIN */}

            <main className="admin-main">

                <header className="admin-header">

                    <div>

                        <p className="header-label">
                            BOOK MANAGEMENT
                        </p>

                        <h1>
                            Manage{" "}
                            <span>Books</span>
                        </h1>

                        <p className="header-description">
                            Review and manage all submitted
                            books and their publishing status.
                        </p>

                    </div>

                    <button
                        className="header-books-button"
                        onClick={() =>
                            navigate("/dashboard")
                        }
                    >
                        ← Dashboard
                    </button>

                </header>

                {/* ERROR */}

                {error && (
                    <div className="dashboard-error">
                        <span>!</span>
                        {error}
                    </div>
                )}

                {/* TOOLBAR */}

                <section className="books-management-card">

                    <div className="books-toolbar">

                        <div className="search-box">

                            <span>⌕</span>

                            <input
                                type="text"
                                placeholder="Search by title, author or category..."
                                value={search}
                                onChange={(e) =>
                                    setSearch(
                                        e.target.value
                                    )
                                }
                            />

                        </div>

                        <div className="filter-box">

                            <label>
                                Status
                            </label>

                            <select
                                value={statusFilter}
                                onChange={(e) =>
                                    setStatusFilter(
                                        e.target.value
                                    )
                                }
                            >
                                <option value="All">
                                    All
                                </option>

                                <option value="Pending">
                                    Pending
                                </option>

                                <option value="Approved">
                                    Approved
                                </option>

                                <option value="Published">
                                    Published
                                </option>

                                <option value="Rejected">
                                    Rejected
                                </option>
                            </select>

                        </div>

                    </div>

                    {/* TABLE */}

                    {loading ? (

                        <div className="empty-state">

                            <div className="dashboard-loader"></div>

                            <p>
                                Loading books...
                            </p>

                        </div>

                    ) : filteredBooks.length === 0 ? (

                        <div className="empty-state">

                            <div className="empty-icon">
                                ▤
                            </div>

                            <h3>
                                No books found
                            </h3>

                            <p>
                                Try changing your search
                                or status filter.
                            </p>

                        </div>

                    ) : (

                        <div className="books-table-wrapper">

                            <table className="books-table manage-books-table">

                                <thead>

                                    <tr>
                                        <th>BOOK</th>
                                        <th>AUTHOR</th>
                                        <th>CATEGORY</th>
                                        <th>STATUS</th>
                                        <th>SUBMITTED</th>
                                        <th>ACTION</th>
                                    </tr>

                                </thead>

                                <tbody>

                                    {filteredBooks.map(
                                        (book) => (

                                            <tr
                                                key={book.id}
                                            >

                                                <td>

                                                    <div className="book-title-cell">

                                                        <div className="book-small-cover">

                                                            {book.cover_image ? (
                                                                <img
                                                                    src={
                                                                        book.cover_image
                                                                    }
                                                                    alt={
                                                                        book.title
                                                                    }
                                                                />
                                                            ) : (
                                                                <span>
                                                                    B
                                                                </span>
                                                            )}

                                                        </div>

                                                        <div>

                                                            <strong>
                                                                {
                                                                    book.title
                                                                }
                                                            </strong>

                                                            <small>
                                                                ID #
                                                                {
                                                                    book.id
                                                                }
                                                            </small>

                                                        </div>

                                                    </div>

                                                </td>

                                                <td>

                                                    <div className="author-cell">

                                                        <strong>
                                                            {
                                                                book.author_name ||
                                                                "Unknown"
                                                            }
                                                        </strong>

                                                        <small>
                                                            {
                                                                book.author_email ||
                                                                "—"
                                                            }
                                                        </small>

                                                    </div>

                                                </td>

                                                <td>
                                                    {
                                                        book.category ||
                                                        "General"
                                                    }
                                                </td>

                                                <td>

                                                    <span
                                                        className={`status-badge ${getStatusClass(
                                                            book.status
                                                        )}`}
                                                    >
                                                        {
                                                            book.status
                                                        }
                                                    </span>

                                                </td>

                                                <td>

                                                    {book.created_at
                                                        ? new Date(
                                                              book.created_at
                                                          ).toLocaleDateString(
                                                              "en-IN"
                                                          )
                                                        : "—"}

                                                </td>

                                                <td>

                                                    <button
                                                        className="view-book-button"
                                                        onClick={() =>
                                                            navigate(
                                                                `/books/${book.id}`
                                                            )
                                                        }
                                                    >
                                                        View
                                                        <span>
                                                            →
                                                        </span>
                                                    </button>

                                                </td>

                                            </tr>

                                        )
                                    )}

                                </tbody>

                            </table>

                        </div>

                    )}

                    <div className="books-result-footer">

                        Showing{" "}
                        <strong>
                            {filteredBooks.length}
                        </strong>{" "}
                        of{" "}
                        <strong>
                            {books.length}
                        </strong>{" "}
                        books

                    </div>

                </section>

            </main>

        </div>
    );
}

export default ManageBooks;

