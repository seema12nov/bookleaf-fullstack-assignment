
import {
    BrowserRouter,
    Routes,
    Route,
    Navigate
} from "react-router-dom";

import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import ManageBooks from "./pages/ManageBooks";
import BookDetails from "./pages/BookDetails";

function App() {
    return (
        <BrowserRouter>

            <Routes>

                {/* Default */}
                <Route
                    path="/"
                    element={
                        <Navigate
                            to="/login"
                            replace
                        />
                    }
                />

                {/* Login */}
                <Route
                    path="/login"
                    element={<Login />}
                />

                {/* Dashboard */}
                <Route
                    path="/dashboard"
                    element={<Dashboard />}
                />

                {/* Manage Books */}
                <Route
                    path="/books"
                    element={<ManageBooks />}
                />

                {/* Book Details */}
                <Route
                    path="/books/:id"
                    element={<BookDetails />}
                />

                {/* Unknown Route */}
                <Route
                    path="*"
                    element={
                        <Navigate
                            to="/login"
                            replace
                        />
                    }
                />

            </Routes>

        </BrowserRouter>
    );
}

export default App;
