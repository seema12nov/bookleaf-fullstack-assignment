
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

function BookDetails() {
    const navigate = useNavigate();
    const { id } = useParams();

    const [book, setBook] = useState(null);
    const [loading, setLoading] = useState(true);
    const [actionLoading, setActionLoading] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");

    const user = JSON.parse(localStorage.getItem("user") || "{}");
    const token = localStorage.getItem("token");

    useEffect(() => {
        fetchBook();
    }, [id]);

    const fetchBook = async () => {
        try {
            setLoading(true);
            setError("");

            const response = await axios.get(
                'https://04goseqara.preview.c35.airoapp.ai/api/admin/books',
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            if (response.data.success) {
                const foundBook = response.data.books.find(
                    (item) => String(item.id) === String(id)
                );

                if (!foundBook) {
                    setError("Book not found.");
                    return;
                }

                setBook(foundBook);
            }
        } catch (err) {
            console.error("Book Details Error:", err);

            setError(
                err.response?.data?.message ||
                "Unable to load book details."
            );
        } finally {
            setLoading(false);
        }
    };

    const updateStatus = async (status) => {
        try {
            setActionLoading(true);
            setError("");
            setSuccess("");

            const response = await axios.put(
                `https://04goseqara.preview.c35.airoapp.ai/api/admin/books/${id}/status`,
                {
                    status: status
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            if (response.data.success) {
                setBook((previousBook) => ({
                    ...previousBook,
                    status: status
                }));

                setSuccess(
                    `Book status successfully changed to ${status}.`
                );
            }
        } catch (err) {
            console.error("Status Update Error:", err);

            setError(
                err.response?.data?.message ||
                "Unable to update book status."
            );
        } finally {
            setActionLoading(false);
        }
    };

    const handleLogout = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");

        navigate("/login");
    };

    const getStatusClass = (status) => {
        return status?.toLowerCase() || "pending";
    };

    if (loading) {
        return (
            <div className="admin-layout">

                <aside className="admin-sidebar">

                    <div className="sidebar-brand">

                        <div className="sidebar-logo">
                            <img
                                src="https://static.wixstatic.com/media/6d2cdc_fbad8eb25d304d57be46e9c494a1a355~mv2.jpg/v1/fill/w_360,h_162,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/book%20background%20white.jpg"
                                alt="BookLeaf"
                            />
                        </div>

                    </div>

                </aside>

                <main className="admin-main">

                    <div className="empty-state">

                        <div className="dashboard-loader"></div>

                        <p>
                            Loading book details...
                        </p>

                    </div>

                </main>

            </div>
        );
    }

    return (
        <div className="admin-layout">

            {/* =========================
                SIDEBAR
            ========================== */}

            <aside className="admin-sidebar">

                <div className="sidebar-brand">

                    <div className="sidebar-logo">

                        <img
                            src="https://static.wixstatic.com/media/6d2cdc_fbad8eb25d304d57be46e9c494a1a355~mv2.jpg/v1/fill/w_360,h_162,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/book%20background%20white.jpg"
                            alt="BookLeaf"
                        />

                    </div>

                </div>

                <nav className="sidebar-nav">

                    <button
                        className="nav-item"
                        onClick={() => navigate("/dashboard")}
                    >
                        <span>▦</span>
                        Dashboard
                    </button>

                    <button
                        className="nav-item active"
                        onClick={() => navigate("/books")}
                    >
                        <span>▤</span>
                        Manage Books
                    </button>

                </nav>

                <div className="sidebar-bottom">

                    <div className="admin-mini">

                        <div className="admin-avatar">
                            {user.name
                                ? user.name.charAt(0).toUpperCase()
                                : "A"}
                        </div>

                        <div>

                            <strong>
                                {user.name || "Administrator"}
                            </strong>

                            <small>
                                Administrator
                            </small>

                        </div>

                    </div>

                    <button
                        className="logout-button"
                        onClick={handleLogout}
                    >
                        <span>↪</span>
                        Logout
                    </button>

                </div>

            </aside>

            {/* =========================
                MAIN
            ========================== */}

            <main className="admin-main">

                <header className="admin-header">

                    <div>

                        <p className="header-label">
                            BOOK DETAILS
                        </p>

                        <h1>
                            {book?.title || "Book Details"}
                        </h1>

                        <p className="header-description">
                            Review book information and manage its
                            publishing status.
                        </p>

                    </div>

                    <button
                        className="header-books-button"
                        onClick={() => navigate("/books")}
                    >
                        ← Back to Books
                    </button>

                </header>

                {/* ERROR */}

                {error && (

                    <div className="dashboard-error">

                        <span>!</span>

                        {error}

                    </div>

                )}

                {/* SUCCESS */}

                {success && (

                    <div className="dashboard-success">

                        <span>✓</span>

                        {success}

                    </div>

                )}

                {!book ? (

                    <div className="recent-books-card">

                        <div className="empty-state">

                            <div className="empty-icon">
                                !
                            </div>

                            <h3>
                                Book not found
                            </h3>

                            <p>
                                The requested book could not be found.
                            </p>

                            <button
                                className="view-book-button"
                                onClick={() => navigate("/books")}
                            >
                                Back to Books
                            </button>

                        </div>

                    </div>

                ) : (

                    <section className="book-details-grid">

                        {/* =========================
                            COVER
                        ========================== */}

                        <div className="book-cover-card">

                            <div className="large-book-cover">

                                {book.cover_image ? (

                                    <img
                                        src={book.cover_image}
                                        alt={book.title}
                                    />

                                ) : (

                                    <div className="cover-placeholder">

                                        <span>
                                            BOOK
                                        </span>

                                        <strong>
                                            {book.title?.charAt(0)}
                                        </strong>

                                        <small>
                                            BOOKLEAF
                                        </small>

                                    </div>

                                )}

                            </div>

                        </div>

                        {/* =========================
                            BOOK INFORMATION
                        ========================== */}

                        <div className="book-info-card">

                            <div className="book-info-header">

                                <div>

                                    <span className="detail-label">
                                        BOOK INFORMATION
                                    </span>

                                    <h2>
                                        {book.title}
                                    </h2>

                                </div>

                                <span
                                    className={`status-badge ${getStatusClass(
                                        book.status
                                    )}`}
                                >
                                    {book.status}
                                </span>

                            </div>

                            <div className="book-info-list">

                                <div className="detail-row">

                                    <span>
                                        Book ID
                                    </span>

                                    <strong>
                                        #{book.id}
                                    </strong>

                                </div>

                                <div className="detail-row">

                                    <span>
                                        Author
                                    </span>

                                    <strong>
                                        {book.author_name || "Unknown"}
                                    </strong>

                                </div>

                                <div className="detail-row">

                                    <span>
                                        Author Email
                                    </span>

                                    <strong>
                                        {book.author_email || "—"}
                                    </strong>

                                </div>

                                <div className="detail-row">

                                    <span>
                                        Category
                                    </span>

                                    <strong>
                                        {book.category || "General"}
                                    </strong>

                                </div>

                                <div className="detail-row">

                                    <span>
                                        Submitted
                                    </span>

                                    <strong>
                                        {book.created_at
                                            ? new Date(
                                                  book.created_at
                                              ).toLocaleDateString(
                                                  "en-IN",
                                                  {
                                                      day: "2-digit",
                                                      month: "short",
                                                      year: "numeric"
                                                  }
                                              )
                                            : "—"}
                                    </strong>

                                </div>

                                <div className="detail-row">

                                    <span>
                                        Last Updated
                                    </span>

                                    <strong>
                                        {book.updated_at
                                            ? new Date(
                                                  book.updated_at
                                              ).toLocaleDateString(
                                                  "en-IN",
                                                  {
                                                      day: "2-digit",
                                                      month: "short",
                                                      year: "numeric"
                                                  }
                                              )
                                            : "—"}
                                    </strong>

                                </div>

                            </div>

                        </div>

                        {/* =========================
                            DESCRIPTION
                        ========================== */}

                        <div className="book-description-card">

                            <div className="detail-section-title">
                                DESCRIPTION
                            </div>

                            <p>
                                {book.description ||
                                    "No description available for this book."}
                            </p>

                        </div>

                        {/* =========================
                            ACTIONS
                        ========================== */}

                        <div className="book-actions-card">

                            <div>

                                <span className="detail-label">
                                    PUBLISHING ACTIONS
                                </span>

                                <h3>
                                    Update Book Status
                                </h3>

                                <p>
                                    Choose the appropriate status for
                                    this book submission.
                                </p>

                            </div>

                            <div className="status-actions">

                                <button
                                    className="status-action approve"
                                    disabled={actionLoading}
                                    onClick={() =>
                                        updateStatus("Approved")
                                    }
                                >
                                    ✓
                                    <span>
                                        Approve
                                    </span>
                                </button>

                                <button
                                    className="status-action reject"
                                    disabled={actionLoading}
                                    onClick={() =>
                                        updateStatus("Rejected")
                                    }
                                >
                                    ×
                                    <span>
                                        Reject
                                    </span>
                                </button>

                                <button
                                    className="status-action publish"
                                    disabled={actionLoading}
                                    onClick={() =>
                                        updateStatus("Published")
                                    }
                                >
                                    ◉
                                    <span>
                                        Publish
                                    </span>
                                </button>

                            </div>

                            {actionLoading && (

                                <div className="action-loading">
                                    Updating book status...
                                </div>

                            )}

                        </div>

                    </section>

                )}

            </main>

        </div>
    );
}

export default BookDetails;
