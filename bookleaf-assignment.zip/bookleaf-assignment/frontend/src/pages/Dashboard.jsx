import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function Dashboard() {
    const navigate = useNavigate();

    const [books, setBooks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    const user = JSON.parse(localStorage.getItem("user") || "{}");
    const token = localStorage.getItem("token");

    useEffect(() => {
        fetchBooks();
    }, []);

    const fetchBooks = async () => {
        try {
            setLoading(true);
            setError("");

            const response = await axios.get(
                "https://04goseqara.preview.c35.airoapp.ai/api/admin/books",
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            if (response.data.success) {
                setBooks(response.data.books || []);
            }
        } catch (err) {
            console.error("Dashboard Error:", err);

            setError(
                err.response?.data?.message ||
                "Unable to load dashboard data."
            );
        } finally {
            setLoading(false);
        }
    };

    const totalBooks = books.length;

    const pendingBooks = books.filter(
        (book) => book.status === "Pending"
    ).length;

    const approvedBooks = books.filter(
        (book) => book.status === "Approved"
    ).length;

    const publishedBooks = books.filter(
        (book) => book.status === "Published"
    ).length;

    const rejectedBooks = books.filter(
        (book) => book.status === "Rejected"
    ).length;

    const handleLogout = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");

        navigate("/login");
    };

    const getStatusClass = (status) => {
        return status?.toLowerCase() || "pending";
    };

    return (
        <div className="admin-layout">

            {/* ================= SIDEBAR ================= */}

            <aside className="admin-sidebar">

                <div className="sidebar-brand">

                    <div className="sidebar-logo">
                        <img
                            src="https://static.wixstatic.com/media/6d2cdc_fbad8eb25d304d57be46e9c494a1a355~mv2.jpg/v1/fill/w_360,h_162,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/book%20background%20white.jpg"
                            alt="BookLeaf"
                        />
                    </div>

                </div>

                <nav className="sidebar-nav">

                    <button
                        className="nav-item active"
                        onClick={() => navigate("/dashboard")}
                    >
                        <span>▦</span>
                        Dashboard
                    </button>

                    <button
                        className="nav-item"
                        onClick={() => navigate("/books")}
                    >
                        <span>▤</span>
                        Manage Books
                    </button>

                </nav>

                <div className="sidebar-bottom">

                    <div className="admin-mini">

                        <div className="admin-avatar">
                            {user.name
                                ? user.name.charAt(0).toUpperCase()
                                : "A"}
                        </div>

                        <div>
                            <strong>
                                {user.name || "Administrator"}
                            </strong>

                            <small>
                                Administrator
                            </small>
                        </div>

                    </div>

                    <button
                        className="logout-button"
                        onClick={handleLogout}
                    >
                        <span>↪</span>
                        Logout
                    </button>

                </div>

            </aside>


            {/* ================= MAIN CONTENT ================= */}

            <main className="admin-main">

                <header className="admin-header">

                    <div>
                        <p className="header-label">
                            ADMIN DASHBOARD
                        </p>

                        <h1>
                            Welcome back,{" "}
                            <span>
                                {user.name || "Admin"}
                            </span>
                        </h1>

                        <p className="header-description">
                            Manage your books and publishing workflow
                            from one place.
                        </p>
                    </div>

                    <button
                        className="header-books-button"
                        onClick={() => navigate("/books")}
                    >
                        Manage Books
                        <span>→</span>
                    </button>

                </header>


                {/* ================= ERROR ================= */}

                {error && (
                    <div className="dashboard-error">
                        <span>!</span>
                        {error}
                    </div>
                )}


                {/* ================= STAT CARDS ================= */}

                <section className="stats-grid">

                    <div className="stat-card">

                        <div className="stat-top">
                            <span className="stat-icon pink">
                                ▤
                            </span>

                            <span className="stat-label">
                                TOTAL BOOKS
                            </span>
                        </div>

                        <strong>
                            {loading ? "—" : totalBooks}
                        </strong>

                        <p>
                            All submitted books
                        </p>

                    </div>


                    <div className="stat-card">

                        <div className="stat-top">
                            <span className="stat-icon orange">
                                ◷
                            </span>

                            <span className="stat-label">
                                PENDING
                            </span>
                        </div>

                        <strong>
                            {loading ? "—" : pendingBooks}
                        </strong>

                        <p>
                            Waiting for review
                        </p>

                    </div>


                    <div className="stat-card">

                        <div className="stat-top">
                            <span className="stat-icon green">
                                ✓
                            </span>

                            <span className="stat-label">
                                APPROVED
                            </span>
                        </div>

                        <strong>
                            {loading ? "—" : approvedBooks}
                        </strong>

                        <p>
                            Approved books
                        </p>

                    </div>


                    <div className="stat-card">

                        <div className="stat-top">
                            <span className="stat-icon purple">
                                ◉
                            </span>

                            <span className="stat-label">
                                PUBLISHED
                            </span>
                        </div>

                        <strong>
                            {loading ? "—" : publishedBooks}
                        </strong>

                        <p>
                            Published books
                        </p>

                    </div>


                    <div className="stat-card">

                        <div className="stat-top">
                            <span className="stat-icon red">
                                ×
                            </span>

                            <span className="stat-label">
                                REJECTED
                            </span>
                        </div>

                        <strong>
                            {loading ? "—" : rejectedBooks}
                        </strong>

                        <p>
                            Rejected submissions
                        </p>

                    </div>

                </section>


                {/* ================= RECENT BOOKS ================= */}

                <section className="dashboard-section">

                    <div className="section-heading">

                        <div>
                            <h2>
                                Recent Books
                            </h2>

                            <p>
                                Latest book submissions
                            </p>
                        </div>

                        <button
                            className="view-all-button"
                            onClick={() => navigate("/books")}
                        >
                            View all →
                        </button>

                    </div>


                    <div className="recent-books-card">

                        {loading ? (

                            <div className="empty-state">
                                <div className="dashboard-loader"></div>
                                <p>
                                    Loading books...
                                </p>
                            </div>

                        ) : books.length === 0 ? (

                            <div className="empty-state">
                                <div className="empty-icon">
                                    ▤
                                </div>

                                <h3>
                                    No books yet
                                </h3>

                                <p>
                                    Book submissions will appear here.
                                </p>
                            </div>

                        ) : (

                            <div className="books-table-wrapper">

                                <table className="books-table">

                                    <thead>
                                        <tr>
                                            <th>BOOK</th>
                                            <th>AUTHOR</th>
                                            <th>CATEGORY</th>
                                            <th>STATUS</th>
                                            <th>DATE</th>
                                        </tr>
                                    </thead>

                                    <tbody>

                                        {books
                                            .slice(0, 5)
                                            .map((book) => (

                                                <tr
                                                    key={book.id}
                                                    onClick={() =>
                                                        navigate(
                                                            `/books/${book.id}`
                                                        )
                                                    }
                                                >

                                                    <td>
                                                        <div className="book-title-cell">

                                                            <div className="book-small-cover">

                                                                {book.cover_image ? (
                                                                    <img
                                                                        src={book.cover_image}
                                                                        alt={book.title}
                                                                    />
                                                                ) : (
                                                                    <span>
                                                                        B
                                                                    </span>
                                                                )}

                                                            </div>

                                                            <strong>
                                                                {book.title}
                                                            </strong>

                                                        </div>
                                                    </td>

                                                    <td>
                                                        {book.author_name ||
                                                            book.author ||
                                                            "Unknown"}
                                                    </td>

                                                    <td>
                                                        {book.category ||
                                                            "General"}
                                                    </td>

                                                    <td>
                                                        <span
                                                            className={`status-badge ${getStatusClass(
                                                                book.status
                                                            )}`}
                                                        >
                                                            {book.status}
                                                        </span>
                                                    </td>

                                                    <td>
                                                        {book.created_at
                                                            ? new Date(
                                                                  book.created_at
                                                              ).toLocaleDateString(
                                                                  "en-IN"
                                                              )
                                                            : "—"}
                                                    </td>

                                                </tr>

                                            ))}

                                    </tbody>

                                </table>

                            </div>

                        )}

                    </div>

                </section>

            </main>

        </div>
    );
}

export default Dashboard;