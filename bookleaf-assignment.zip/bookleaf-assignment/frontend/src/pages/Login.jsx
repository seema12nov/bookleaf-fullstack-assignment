import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function Login() {
    const navigate = useNavigate();

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const handleLogin = async (e) => {
        e.preventDefault();

        setError("");

        if (!email || !password) {
            setError("Please enter email and password.");
            return;
        }

        try {
            setLoading(true);

            const response = await axios.post(
                "https://m75soyoyq1.c38.airoapp.ai/api/auth/login",
                {
                    email,
                    password
                }
            );

            if (response.data.success) {
                localStorage.setItem(
                    "token",
                    response.data.token
                );

                localStorage.setItem(
                    "user",
                    JSON.stringify(response.data.user)
                );

                navigate("/dashboard");
            }
        } catch (error) {
            console.error("Login Error:", error);

            setError(
                error.response?.data?.message ||
                "Invalid email or password."
            );
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="login-page">

            <div className="login-card">

                {/* =====================================
                    LEFT BRANDING SECTION
                ====================================== */}

                <div className="login-left">

                    {/* LOGO */}
                    <div className="brand">

                        <div className="brand-logo">
                            <img
                                src="https://static.wixstatic.com/media/6d2cdc_fbad8eb25d304d57be46e9c494a1a355~mv2.jpg/v1/fill/w_360,h_162,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/book%20background%20white.jpg"
                                alt="BookLeaf"
                            />
                        </div>

                        <div className="brand-text">
                            <div className="brand-name">
                                BookLeaf
                            </div>

                            <div className="brand-subtitle">
                                Admin Panel
                            </div>
                        </div>

                    </div>


                    {/* LEFT CONTENT */}

                    <div className="left-content">

                        <div className="badge">
                            ADMINISTRATION
                        </div>

                        <h1>
                            Manage your
                            <span> publishing </span>
                            world.
                        </h1>

                        <p>
                            Review books, manage submissions and
                            control the publishing workflow from
                            one powerful dashboard.
                        </p>

                    </div>


                    {/* BOOK DECORATION */}

                    <div className="books">

                        <div className="book book-1">
                            BOOK
                        </div>

                        <div className="book book-2">
                            LEAF
                        </div>

                        <div className="book book-3">
                            READ
                        </div>

                    </div>


                    {/* FOOTER */}

                    <div className="left-footer">

                        BOOKS
                        <span>•</span>
                        CREATE
                        <span>•</span>
                        PUBLISH

                    </div>

                </div>


                {/* =====================================
                    RIGHT LOGIN SECTION
                ====================================== */}

                <div className="login-right">

                    <div className="login-content">

                        {/* WELCOME ICON */}

                        <div className="welcome-icon">
                            👋
                        </div>


                        {/* HEADING */}

                        <h2>
                            Welcome back
                        </h2>

                        <p className="welcome-text">
                            Sign in to manage books and
                            publishing activities.
                        </p>


                        {/* ERROR */}

                        {error && (
                            <div className="error-message">

                                <span>!</span>

                                {error}

                            </div>
                        )}


                        {/* LOGIN FORM */}

                        <form onSubmit={handleLogin}>

                            {/* EMAIL */}

                            <div className="form-group">

                                <label htmlFor="email">
                                    Email Address
                                </label>

                                <div className="input-box">

                                    <span className="input-icon">
                                        ✉
                                    </span>

                                    <input
                                        id="email"
                                        type="email"
                                        placeholder="admin@example.com"
                                        value={email}
                                        onChange={(e) =>
                                            setEmail(e.target.value)
                                        }
                                        autoComplete="email"
                                    />

                                </div>

                            </div>


                            {/* PASSWORD */}

                            <div className="form-group">

                                <label htmlFor="password">
                                    Password
                                </label>

                                <div className="input-box">

                                    <span className="input-icon">
                                        ●
                                    </span>

                                    <input
                                        id="password"
                                        type="password"
                                        placeholder="Enter your password"
                                        value={password}
                                        onChange={(e) =>
                                            setPassword(e.target.value)
                                        }
                                        autoComplete="current-password"
                                    />

                                </div>

                            </div>


                            {/* SIGN IN BUTTON */}

                            <button
                                type="submit"
                                className="sign-in-button"
                                disabled={loading}
                            >

                                {loading ? (
                                    <>
                                        <span className="loading"></span>
                                        Signing in...
                                    </>
                                ) : (
                                    <>
                                        Sign In
                                        <span className="button-arrow">
                                            →
                                        </span>
                                    </>
                                )}

                            </button>

                        </form>


                        {/* SECURITY */}

                        <div className="secure">

                            <span>✓</span>

                            Secure admin access

                        </div>


                        {/* COPYRIGHT */}

                        <div className="copyright">
                            © 2026 BookLeaf Admin Panel
                        </div>

                    </div>

                </div>

            </div>

        </div>
    );
}

export default Login;